# 🔑🔓🖥️ Browser Passwords

This is a simple package that collects passwords from Brave, Chrome & Mozilla.